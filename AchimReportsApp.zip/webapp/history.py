"""
Report run history — per-user JSON storage.

Stores a record each time a report is run, so users can revisit
past results and re-download Excel files.

Statuses: running, completed, failed, no_data
"""

import json
import logging
import os
import re
import uuid
from datetime import datetime

from webapp.config import WEBAPP_DIR

log = logging.getLogger(__name__)

HISTORY_DIR = os.path.join(WEBAPP_DIR, "_history")
os.makedirs(HISTORY_DIR, exist_ok=True)

MAX_HISTORY = 50


def _user_file(email: str) -> str:
    safe = re.sub(r"[^a-z0-9]+", "_", email.lower().strip())
    return os.path.join(HISTORY_DIR, f"{safe}.json")


def _load(email: str) -> list[dict]:
    path = _user_file(email)
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        log.exception("Failed to read history for %s", email)
        return []


def _save(email: str, records: list[dict]):
    path = _user_file(email)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, default=str)
    except Exception:
        log.exception("Failed to save history for %s", email)


def add_record(email: str, report_key: str, report_name: str,
               params: dict, status: str = "running",
               filepath: str | None = None, filename: str | None = None,
               summary: dict | None = None, error: str | None = None) -> str:
    """Append a report run to the user's history. Returns the record_id."""
    records = _load(email)
    record_id = uuid.uuid4().hex[:12]
    records.insert(0, {
        "record_id": record_id,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "report_key": report_key,
        "report_name": report_name,
        "params": params,
        "status": status,
        "filepath": filepath,
        "filename": filename,
        "summary": summary or {},
        "error": error,
    })
    records = records[:MAX_HISTORY]
    _save(email, records)
    return record_id


def update_record(email: str, record_id: str, **fields):
    """Update fields on an existing history record by record_id."""
    records = _load(email)
    for rec in records:
        if rec.get("record_id") == record_id:
            rec.update(fields)
            break
    _save(email, records)


def get_history(email: str) -> list[dict]:
    """Return the user's report history, newest first."""
    records = _load(email)
    for rec in records:
        if rec.get("filepath") and not os.path.isfile(rec["filepath"]):
            rec["file_available"] = False
        else:
            rec["file_available"] = bool(rec.get("filepath"))
    return records
