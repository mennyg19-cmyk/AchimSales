"""
Maps Microsoft account emails to salesman keys and roles.

Reads user_map.json to determine:
  - Whether a user is authorized at all
  - Whether they are a salesman (and which one) or an admin
"""

import json
import logging
import os
from functools import lru_cache

from webapp.config import USER_MAP_PATH

log = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def _load_map() -> dict:
    if not os.path.isfile(USER_MAP_PATH):
        log.warning("user_map.json not found at %s", USER_MAP_PATH)
        return {}
    with open(USER_MAP_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def reload_map():
    """Clear the cache so the next lookup rereads the file."""
    _load_map.cache_clear()


def get_user(email: str) -> dict | None:
    """Look up a user by email. Returns their role info dict or None if not authorized."""
    data = _load_map()
    users = data.get("users", {})
    return users.get(email.lower().strip())


def is_admin(user_info: dict) -> bool:
    return user_info.get("role") == "admin"


def is_salesman(user_info: dict) -> bool:
    return user_info.get("role") == "salesman"


def get_salesman_key(user_info: dict) -> str | None:
    """Return the salesman_key for a salesman user, or None for admins."""
    if is_salesman(user_info):
        return user_info.get("salesman_key")
    return None


REPORTS_CONFIG = {
    "ordered": {
        "name": "Ordered Report",
        "description": "Sales orders: ordered, shipped, cancelled, remaining",
        "salesman_filter": True,
        "customer_filter": True,
        "has_period": True,
        "has_status": True,
        "icon": "package",
    },
    "invoiced": {
        "name": "Invoiced Report",
        "name_salesman": "Shipped Report",
        "description": "Invoices with commissions and freight details",
        "description_salesman": "Your shipped orders with commissions and freight details",
        "salesman_filter": True,
        "customer_filter": True,
        "has_period": True,
        "has_status": False,
        "icon": "file-text",
    },
    "salesman": {
        "name": "Salesman Report",
        "description": "Monthly salesman comparison: current vs prior year",
        "salesman_filter": False,
        "customer_filter": False,
        "has_period": False,
        "has_status": False,
        "has_year": True,
        "icon": "users",
    },
    "number_4": {
        "name": "Number 4 Report",
        "description": "Invoice lines by item and by customer (rolling 12 months)",
        "salesman_filter": False,
        "customer_filter": False,
        "has_period": False,
        "has_status": False,
        "icon": "bar-chart-2",
    },
    "amazon_weekly": {
        "name": "Amazon Weekly",
        "description": "Amazon (customer 9300) orders for the last 7 days",
        "salesman_filter": False,
        "customer_filter": False,
        "has_period": False,
        "has_status": False,
        "icon": "shopping-cart",
    },
    "customer_activity": {
        "name": "Customer Activity",
        "description": "All customers with last order info, split by salesman",
        "salesman_filter": True,
        "customer_filter": False,
        "has_period": False,
        "has_status": False,
        "icon": "activity",
    },
}


def get_available_reports(user_info: dict) -> dict:
    """Return the reports available to this user based on their role.

    For salesman users, reports with salesman-specific names/descriptions
    are returned with those overrides applied.
    """
    if is_admin(user_info):
        return REPORTS_CONFIG.copy()

    result = {}
    for key, cfg in REPORTS_CONFIG.items():
        if not cfg.get("salesman_filter", False):
            continue
        entry = cfg.copy()
        if "name_salesman" in entry:
            entry["name"] = entry["name_salesman"]
        if "description_salesman" in entry:
            entry["description"] = entry["description_salesman"]
        result[key] = entry
    return result
