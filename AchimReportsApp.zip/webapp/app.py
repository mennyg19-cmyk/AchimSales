"""
Sales Reports Web App — Flask entry point.

Mobile-friendly web app for running D365 sales reports.
Authenticated via Microsoft Entra ID (Azure AD).
"""

import json
import logging
import os
import sys

_SCRIPTS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)

from flask import (
    Flask,
    Response,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

from webapp.config import FLASK_SECRET

# Set to True to bypass Microsoft login and auto-sign-in as admin (for local dev)
DEV_BYPASS_AUTH = True
from webapp.user_map import (
    get_available_reports,
    get_salesman_key,
    get_user,
    is_admin,
    is_salesman,
    reload_map,
    REPORTS_CONFIG,
)
from webapp.report_api import run_report
from webapp.history import add_record, update_record, get_history

import threading
import queue
import time as _time

_progress_queues: dict[str, queue.Queue] = {}

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
)
app.secret_key = FLASK_SECRET


def _get_current_user():
    """Return the current user dict from session, or None."""
    return session.get("user")


def _require_login(f):
    """Decorator: redirect to login if not authenticated."""
    from functools import wraps

    @wraps(f)
    def wrapper(*args, **kwargs):
        user = _get_current_user()
        if not user:
            return redirect(url_for("login"))
        return f(*args, **kwargs)

    return wrapper


@app.route("/")
def index():
    user = _get_current_user()
    if user:
        return redirect(url_for("home"))
    return redirect(url_for("login"))


@app.route("/login")
def login():
    user = _get_current_user()
    if user:
        return redirect(url_for("home"))
    if DEV_BYPASS_AUTH:
        return render_template("login_dev.html")
    return render_template("login.html")


@app.route("/login/start")
def login_start():
    """Redirect to Microsoft login."""
    if DEV_BYPASS_AUTH:
        return redirect(url_for("dev_login"))
    try:
        from webapp.auth import build_login_url
        auth_url = build_login_url()
        return redirect(auth_url)
    except Exception:
        log.exception("Failed to build login URL")
        flash("Could not connect to Microsoft login. Please try again.", "error")
        return redirect(url_for("login"))


@app.route("/dev-login", methods=["GET", "POST"])
def dev_login():
    """Dev-only: bypass Microsoft login, pick a role to sign in as."""
    if not DEV_BYPASS_AUTH:
        return redirect(url_for("login"))

    if request.method == "POST":
        role = request.form.get("role", "admin")
        if role == "admin":
            session["user"] = {
                "email": "dev-admin@localhost",
                "name": "Dev Admin",
                "role": "admin",
                "salesman_key": None,
            }
        else:
            sm_key = request.form.get("salesman_key", "mkolko")
            from config.salesman_map import lookup_salesman
            _, full_name, display_name = lookup_salesman(sm_key)
            session["user"] = {
                "email": f"dev-{sm_key}@localhost",
                "name": full_name,
                "role": "salesman",
                "salesman_key": sm_key,
            }
        return redirect(url_for("home"))

    salesmen = []
    try:
        from config.salesman_map import SALESMAN_MAP
        salesmen = [
            {"key": k, "name": v[1]}
            for k, v in SALESMAN_MAP.items()
            if v[0] != "?unassigned"
        ]
        salesmen.sort(key=lambda x: x["name"])
    except Exception:
        pass

    return render_template("login_dev.html", salesmen=salesmen)


@app.route("/auth/callback", methods=["GET", "POST"])
def auth_callback():
    """Handle the redirect from Microsoft after login."""
    from webapp.auth import complete_login
    ms_user = complete_login()
    if not ms_user:
        flash("Login failed. Please try again.", "error")
        return redirect(url_for("login"))

    email = ms_user.get("email", "")
    user_info = get_user(email)
    if not user_info:
        return render_template("unauthorized.html", email=email)

    session["user"] = {
        "email": email,
        "name": ms_user.get("name", email),
        "role": user_info["role"],
        "salesman_key": user_info.get("salesman_key"),
    }
    return redirect(url_for("home"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/home")
@_require_login
def home():
    """Dashboard: show available reports based on user role."""
    user = _get_current_user()
    reports = get_available_reports(user)
    return render_template("home.html", user=user, reports=reports)


@app.route("/report/<report_key>")
@_require_login
def report_form(report_key):
    """Show the parameter form for a specific report."""
    user = _get_current_user()
    available = get_available_reports(user)

    if report_key not in available:
        flash("You do not have access to this report.", "error")
        return redirect(url_for("home"))

    report_cfg = available[report_key]
    salesman_key = get_salesman_key(user)
    user_is_admin = is_admin(user)

    salesmen_list = []
    if user_is_admin and report_cfg.get("salesman_filter"):
        try:
            from config.salesman_map import SALESMAN_MAP
            salesmen_list = [
                {"key": k, "name": v[1], "display": v[2]}
                for k, v in SALESMAN_MAP.items()
                if v[0] != "?unassigned"
            ]
            salesmen_list.sort(key=lambda x: x["name"])
        except Exception:
            log.exception("Failed to load salesmen list")

    return render_template(
        "report_form.html",
        user=user,
        report_key=report_key,
        report=report_cfg,
        salesman_key=salesman_key,
        is_admin=user_is_admin,
        salesmen_list=salesmen_list,
    )


@app.route("/report/<report_key>/run", methods=["POST"])
@_require_login
def report_run(report_key):
    """Start a report run: create history record, launch background thread, return run_id for SSE."""
    user = _get_current_user()
    available = get_available_reports(user)

    if report_key not in available:
        return jsonify({"success": False, "error": "Access denied"}), 403

    params = request.get_json() or {}

    if is_salesman(user) and user.get("salesman_key"):
        report_cfg = available[report_key]
        if report_cfg.get("salesman_filter"):
            params["salesman"] = user["salesman_key"]

    report_cfg = available[report_key]
    email = user.get("email", "")

    record_id = add_record(
        email=email,
        report_key=report_key,
        report_name=report_cfg.get("name", report_key),
        params=params,
        status="running",
    )

    progress_q = queue.Queue()
    _progress_queues[record_id] = progress_q

    def _run_in_background():
        try:
            progress_q.put({"step": "connecting", "pct": 10, "msg": "Connecting to D365..."})
            _time.sleep(0.3)
            progress_q.put({"step": "fetching", "pct": 25, "msg": "Fetching data from D365..."})

            result = run_report(report_key, params)

            if result.get("success"):
                progress_q.put({"step": "processing", "pct": 70, "msg": "Processing data..."})
                _time.sleep(0.2)
                progress_q.put({"step": "writing", "pct": 85, "msg": "Writing Excel file..."})
                _time.sleep(0.2)

                update_record(
                    email, record_id,
                    status="completed" if result.get("filepath") else "no_data",
                    filepath=result.get("filepath"),
                    filename=result.get("filename"),
                    summary=result.get("summary", {}),
                )
                result.pop("traceback", None)
                progress_q.put({"step": "done", "pct": 100, "msg": "Report complete!", "result": result})
            else:
                err = result.get("error", "Unknown error")
                update_record(email, record_id, status="failed", error=err)
                result.pop("traceback", None)
                progress_q.put({"step": "error", "pct": 100, "msg": f"Failed: {err}", "result": result})
        except Exception as e:
            update_record(email, record_id, status="failed", error=str(e))
            progress_q.put({"step": "error", "pct": 100, "msg": f"Failed: {e}",
                            "result": {"success": False, "error": str(e)}})
        finally:
            progress_q.put(None)

    thread = threading.Thread(target=_run_in_background, daemon=True)
    thread.start()

    log.info("Running report %s (run_id=%s) with params: %s (user: %s)",
             report_key, record_id, params, email)

    return jsonify({"run_id": record_id})


@app.route("/report/progress/<run_id>")
@_require_login
def report_progress(run_id):
    """SSE endpoint: stream progress updates for a running report."""
    progress_q = _progress_queues.get(run_id)

    def generate():
        if not progress_q:
            yield f"data: {json.dumps({'step': 'error', 'pct': 100, 'msg': 'Run not found', 'result': {'success': False, 'error': 'Run not found'}})}\n\n"
            return

        while True:
            try:
                msg = progress_q.get(timeout=120)
            except queue.Empty:
                yield f"data: {json.dumps({'step': 'error', 'pct': 100, 'msg': 'Timeout', 'result': {'success': False, 'error': 'Report timed out'}})}\n\n"
                break

            if msg is None:
                _progress_queues.pop(run_id, None)
                break

            yield f"data: {json.dumps(msg, default=str)}\n\n"

            if msg.get("step") in ("done", "error"):
                _progress_queues.pop(run_id, None)
                break

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/report/<report_key>/download")
@_require_login
def report_download(report_key):
    """Download the most recently generated Excel file for a report."""
    user = _get_current_user()
    filepath = session.get(f"download_{report_key}")

    if not filepath or not os.path.isfile(filepath):
        records = get_history(user.get("email", ""))
        for rec in records:
            if rec.get("report_key") == report_key and rec.get("file_available"):
                filepath = rec["filepath"]
                break

    if not filepath or not os.path.isfile(filepath):
        flash("No report file available for download. Please run the report first.", "error")
        return redirect(url_for("report_form", report_key=report_key))

    return send_file(filepath, as_attachment=True, download_name=os.path.basename(filepath))


@app.route("/history")
@_require_login
def history():
    """Show the user's report run history."""
    user = _get_current_user()
    records = get_history(user.get("email", ""))
    return render_template("history.html", user=user, records=records)


@app.route("/history/download/<int:record_idx>")
@_require_login
def history_download(record_idx):
    """Download an Excel file from history."""
    user = _get_current_user()
    records = get_history(user.get("email", ""))
    if record_idx < 0 or record_idx >= len(records):
        flash("Report not found in history.", "error")
        return redirect(url_for("history"))

    rec = records[record_idx]
    filepath = rec.get("filepath")
    if not filepath or not os.path.isfile(filepath):
        flash("The file for this report is no longer available.", "error")
        return redirect(url_for("history"))

    return send_file(filepath, as_attachment=True, download_name=rec.get("filename", os.path.basename(filepath)))


@app.route("/history/view/<int:record_idx>")
@_require_login
def history_view(record_idx):
    """Re-view results from a past report run."""
    user = _get_current_user()
    records = get_history(user.get("email", ""))
    if record_idx < 0 or record_idx >= len(records):
        flash("Report not found in history.", "error")
        return redirect(url_for("history"))

    rec = records[record_idx]
    filepath = rec.get("filepath")

    sheets = {}
    if filepath and os.path.isfile(filepath):
        from webapp.report_api import _read_excel_sheets
        sheets = _read_excel_sheets(filepath)

    return render_template(
        "history_view.html",
        user=user,
        record=rec,
        record_idx=record_idx,
        sheets=sheets,
    )


@app.route("/api/customers")
@_require_login
def api_customers():
    """Return customer list, optionally filtered by salesman."""
    user = _get_current_user()
    salesman_key = None

    if is_salesman(user):
        salesman_key = user.get("salesman_key")
    elif is_admin(user) and request.args.get("salesman"):
        salesman_key = request.args.get("salesman")

    try:
        from config.settings import (
            get_client_id,
            get_client_secret,
            get_company_id,
            get_d365_env_url,
            get_tenant_id,
            validate_d365_config,
        )
        from core.auth import get_d365_token
        from data.d365_entities import fetch_customers

        validate_d365_config()
        env_url = get_d365_env_url().rstrip("/")
        base_url = (
            f"{env_url}/data/"
            if "/data" not in env_url.lower()
            else (env_url if env_url.endswith("/") else f"{env_url}/")
        )
        token = get_d365_token(get_tenant_id(), get_client_id(), get_client_secret(), env_url)
        company = get_company_id() or None

        df = fetch_customers(base_url, token, company)

        if df.empty:
            return jsonify([])

        if salesman_key and "SalesGroup" in df.columns:
            import re
            norm = re.sub(r"[^a-z0-9]+", "", salesman_key.lower())
            df["_norm_sg"] = df["SalesGroup"].fillna("").astype(str).str.lower().str.replace(
                r"[^a-z0-9]+", "", regex=True
            )
            df = df[df["_norm_sg"] == norm].drop(columns=["_norm_sg"])

        customers = []
        for _, row in df.iterrows():
            customers.append({
                "account": str(row.get("CustomerAccount", "")),
                "name": str(row.get("CustomerName", "")),
            })

        customers.sort(key=lambda c: c["name"])
        return jsonify(customers)

    except Exception:
        log.exception("Failed to fetch customers")
        return jsonify([]), 500


@app.route("/api/reload-users", methods=["POST"])
@_require_login
def api_reload_users():
    """Reload the user map from disk (admin only)."""
    user = _get_current_user()
    if not is_admin(user):
        return jsonify({"error": "Admin only"}), 403
    reload_map()
    return jsonify({"success": True})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
